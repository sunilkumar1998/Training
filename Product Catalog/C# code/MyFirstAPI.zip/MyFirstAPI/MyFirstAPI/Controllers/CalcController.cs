﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyFirstAPI.Infrastructure;
using MyFirstAPI.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalcController : ControllerBase
    {
        
            
        private readonly productItemContext _context;
        public CalcController(productItemContext context)
        {
            _context = context;
        }

        [HttpGet("items")]
        public List<productItem> getItems()
        {
            var result = from r in _context.todoItems select r;
            return result.ToList();
        }


        [HttpGet("items/{id}")]
        public productItem  getItem(int id)
        {
            productItem result =( from r in _context.todoItems where r.Id==id select r ).ToList().First();
            return result;
        }

        [HttpPost("items")]
        public productItem createItem(productItem item)
        {
            _context.todoItems.Add(item);
            _context.SaveChanges();
            return item;
        }

        [HttpPut("items/{id}")]
        public productItem updateItem(productItem item)
        {
            _context.Entry(item).State = EntityState.Modified;
            _context.SaveChanges();
            return item;
        }

        [HttpDelete("items/{id}")]
        public async Task<ActionResult<productItem>> DeleteProduct(int id)
        {
            var product = await _context.todoItems.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.todoItems.Remove(product);
            await _context.SaveChangesAsync();

            return product;
        }
    }
}
