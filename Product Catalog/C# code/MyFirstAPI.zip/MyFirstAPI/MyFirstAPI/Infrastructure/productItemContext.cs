﻿using Microsoft.EntityFrameworkCore;
using MyFirstAPI.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstAPI.Infrastructure
{
    public class productItemContext:DbContext
    {
        public DbSet<productItem> todoItems { get; set; }

        public productItemContext(DbContextOptions<productItemContext> options) : base(options)
        {
        }
    }
}
